#!/usr/bin/env node

class Bundler {
    modules;
    loaded;
    name;
    constructor(name) {
        this.modules = new Map();
        this.loaded = new Map();
        this.name = name;
    }
    register(id, requires, module) {
        this.modules.set(id, {
            config: {},
            imports: requires,
            module: module
        });
    }
    load(...items) {
        for (let i = 0; i < items.length; i++) {
            const [status] = this.loadItem(items[i]);
            if (!status) {
                return;
            }
        }
    }
    loadItem(item) {
        if (!this.modules.has(item)) {
            let domain = item.split("_")[0];
            if (typeof window == "undefined") {
                if (typeof global["domain"] == "undefined") {
                    console.error(`BUNDLER: Cannot resolve '${item}'`);
                    return [false, []];
                }
                if (global["domain"][domain] == "undefined") {
                    console.error(`BUNDLER: Cannot resolve '${item}'`);
                    return [false, []];
                }
                else {
                    return global["domain"][domain].loadItem(item);
                }
            }
            else {
                if (typeof window["domain"] == "undefined") {
                    console.error(`BUNDLER: Cannot resolve '${item}'`);
                    return [false, []];
                }
                if (window["domain"][domain] == "undefined") {
                    console.error(`BUNDLER: Cannot resolve '${item}'`);
                    return [false, []];
                }
                else {
                    return window["domain"][domain].loadItem(item);
                }
            }
        }
        if (this.loaded.has(item)) {
            return [true, this.loaded.get(item)];
        }
        const module = this.modules.get(item);
        let imports = {};
        let exports = {};
        exports[item] = {};
        let config = {
            pragma: "once"
        };
        module.imports.forEach(subitem => {
            const [status, exports] = this.loadItem(subitem);
            if (!status) {
                console.error(`BUNDLER: Could not load reference '${subitem}' in ${item}`);
                return;
            }
            imports[subitem] = exports[subitem];
        });
        module.module(imports, exports, config);
        if (config.pragma == "once") {
            this.loaded.set(item, exports);
        }
        return [true, exports];
    }
}
const bundler = new Bundler("tsb");
if (typeof window == "undefined") {
    if (typeof global["domain"] == "undefined") {
        global["domain"] = {};
    }
    global["domain"]["tsb"] = bundler;
}
else {
    if (typeof window["domain"] == "undefined") {
        window["domain"] = {};
    }
    window["domain"]["tsb"] = bundler;
}
bundler.register("tsb_tsb_0", ["tsb_utils_16", "tsb_build_9", "tsb_sync_12", "tsb_init_10", "tsb_pack_11", "tsb_use_13"], (imports, exports, config) => {
    const { shift } = imports["tsb_utils_16"];
    const build = imports["tsb_build_9"].default;
    const sync = imports["tsb_sync_12"].default;
    const init = imports["tsb_init_10"].default;
    const pack = imports["tsb_pack_11"].default;
    const use = imports["tsb_use_13"].default;
    const path = require("path");
    const fs = require("fs");
    {
        if (__dirname.endsWith("bin")) {
            require("../../utils/utils");
        }
        else {
            fs.readdirSync(path.join(__dirname, "plugins")).forEach((item) => {
                if (item.endsWith(".js")) {
                    require(path.join(__dirname, "plugins", item));
                }
            });
        }
        function usage() {
            console.log("Usage: tsb <command> [<options>]");
            console.log();
            console.log("build [<queue>] [<options>]");
            console.log();
            console.log("Builds the project with a in the config file defined build queue or at default all defined modules");
            console.log();
            console.log("queue:");
            console.log("  Your config name defined in your config file");
            console.log("options:");
            console.log("  --write-ts  Write the typescript file to the output (This file is not 100% syntax secure).");
            console.log();
            console.log("sync [<queue>]");
            console.log();
            console.log("Syncs the project with the settings and plugins set in the config file");
            console.log();
            console.log("queue:");
            console.log("  Your config name defined in your config file");
            console.log();
            console.log("init");
            console.log();
            console.log("Inits a new project");
            console.log();
            console.log("options:");
            console.log("  (--plugin | -p) Inits a project for plugin development");
            console.log();
            console.log("pack <module>");
            console.log();
            console.log("Packs a module to a zip library for easy transfer and usage");
            console.log();
            console.log("module:");
            console.log("  The module that should be packed");
            console.log();
            console.log("use <path>");
            console.log();
            console.log("Includes a library in the current project");
            console.log();
            console.log("path:");
            console.log("  The path of the library");
            console.log();
            console.log("help");
        }
        shift();
        shift();
        const command = shift();
        if (!command) {
            usage();
            process.exit(1);
        }
        if (command == "build") {
            build();
        }
        else if (command == "sync") {
            sync();
        }
        else if (command == "init") {
            init();
        }
        else if (command == "pack") {
            pack();
        }
        else if (command == "use") {
            use();
        }
        else if (command == "help") {
            usage();
        }
    }
});
bundler.register("tsb_config_1", [], (imports, exports, config) => {
    const fs = require("fs");
    const path = require("path");
    {
        let QueueKind;
        (function (QueueKind) {
            QueueKind[QueueKind["COMPILE_MODULE"] = 0] = "COMPILE_MODULE";
            QueueKind[QueueKind["COPY"] = 1] = "COPY";
            QueueKind[QueueKind["REMOVE"] = 2] = "REMOVE";
            QueueKind[QueueKind["SYNC_PLUGIN"] = 3] = "SYNC_PLUGIN";
            QueueKind[QueueKind["PACK"] = 4] = "PACK";
        })(QueueKind || (QueueKind = {}));
        class Serialization {
        }
        class QueueBuilder {
            from;
            queue;
            name;
            constructor(from, name) {
                this.from = from;
                this.name = name;
                this.queue = [];
            }
            compile_module(module) {
                this.queue.push({
                    kind: QueueKind.COMPILE_MODULE,
                    information: {
                        moduleName: module
                    }
                });
                return this;
            }
            remove(path, recursive = false) {
                this.queue.push({
                    kind: QueueKind.REMOVE,
                    information: {
                        target: path,
                        recursive: recursive
                    }
                });
                return this;
            }
            copy(from, to, overwrite = false) {
                this.queue.push({
                    kind: QueueKind.COPY,
                    information: {
                        from: from,
                        to: to,
                        overwrite: overwrite
                    }
                });
                return this;
            }
            pack(module) {
                this.queue.push({
                    kind: QueueKind.PACK,
                    information: {
                        moduleName: module
                    }
                });
                return this;
            }
            done() {
                this.from.set_queue(this.name, this.queue);
                return this.from;
            }
        }
        class ConfigBuilder {
            modules;
            loaders;
            dependencies;
            moduleType;
            plugins;
            queues;
            constructor() {
                this.modules = new Map();
                this.loaders = new Map();
                this.dependencies = new Map();
                this.moduleType = new Map();
                this.plugins = new Map();
                this.queues = new Map();
            }
            current = null;
            add_module(name, paths) {
                let convertedPaths = [];
                paths.forEach(value => {
                    const loop = (root) => {
                        fs.readdirSync(root).forEach(item => {
                            const itemPath = path.join(root, item);
                            if (fs.statSync(itemPath).isFile() && (itemPath.endsWith(".tsx") || itemPath.endsWith(".ts"))) {
                                convertedPaths.push(itemPath.replace(/\\/gi, "/"));
                            }
                            else if (fs.statSync(itemPath).isDirectory()) {
                                loop(itemPath);
                            }
                        });
                    };
                    if (!fs.existsSync(value)) {
                        console.log(`WARNING: The path '${value}' dont exist`);
                        return;
                    }
                    if (fs.statSync(value).isFile()) {
                        convertedPaths.push(value.replace(/\\/gi, "/"));
                    }
                    else if (fs.statSync(value).isDirectory()) {
                        loop(value);
                    }
                });
                this.modules.set(name, convertedPaths);
                this.moduleType.set(name, "module");
                this.loaders.set(name, []);
                this.plugins.set(name, []);
                this.current = name;
                return this;
            }
            select_module(name) {
                if (this.modules.has(name)) {
                    this.current = name;
                }
                else {
                    console.log(`ERROR: The module '${name}' dont exist`);
                    process.exit(1);
                }
                return this;
            }
            add_loader(path) {
                if (!fs.existsSync(path)) {
                    console.log(`WARNING: The path '${path}' dont exist`);
                }
                if (this.current == null) {
                    console.log("ERROR: No module selected at 'add_loader'\nAt one with 'add_module' or select one with 'select_module'");
                    process.exit(1);
                }
                if (!this.loaders.has(this.current)) {
                    this.loaders.set(this.current, [path]);
                }
                else {
                    this.loaders.get(this.current).push(path);
                }
                return this;
            }
            use(name, ...parameters) {
                if (this.current == null) {
                    console.log("ERROR: No module selected at 'use'\nAt one with 'add_module' or select one with 'select_module'");
                    process.exit(1);
                }
                if (!this.plugins.has(this.current)) {
                    this.plugins.set(this.current, [
                        {
                            name: name,
                            parameters: parameters
                        }
                    ]);
                }
                else {
                    this.plugins.get(this.current).push({
                        name: name,
                        parameters: parameters
                    });
                }
                return this;
            }
            dependence(name) {
                if (this.current == null) {
                    console.log("ERROR: No module selected at 'dependence'\nAt one with 'add_module' or select one with 'select_module'");
                    process.exit(1);
                }
                if (!this.dependencies.has(this.current)) {
                    this.dependencies.set(this.current, [name]);
                }
                else {
                    this.dependencies.get(this.current).push(name);
                }
                return this;
            }
            type(type) {
                if (this.current == null) {
                    console.log("ERROR: No module selected at 'dependence'\nAt one with 'type' or select one with 'select_module'");
                    process.exit(1);
                }
                this.moduleType.set(this.current, type);
                return this;
            }
            create_build_queue(name = "all") {
                return new QueueBuilder(this, name);
            }
            set_queue(name, queue) {
                this.queues.set(name, queue);
            }
            build() {
                let modules = {};
                this.modules.forEach((value, key) => {
                    modules[key] = value;
                });
                let loaders = {};
                this.loaders.forEach((value, key) => {
                    loaders[key] = value;
                });
                let dependencies = {};
                this.dependencies.forEach((value, key) => {
                    dependencies[key] = value;
                });
                let plugins = {};
                this.plugins.forEach((value, key) => {
                    plugins[key] = value;
                });
                let moduleType = {};
                this.moduleType.forEach((value, key) => {
                    moduleType[key] = value;
                });
                if (this.queues.size == 0) {
                    const queue = [];
                    this.modules.forEach((value, key) => {
                        queue.push({
                            kind: QueueKind.COMPILE_MODULE,
                            information: {
                                moduleName: key
                            }
                        });
                        this.queues.set("all", queue);
                    });
                }
                const queues = {};
                this.queues.forEach((value, key) => {
                    queues[key] = value;
                });
                return {
                    queues: queues,
                    modules: modules,
                    loaders: loaders,
                    moduleType: moduleType,
                    dependencies: dependencies,
                    plugins: plugins
                };
            }
            write(filePath) {
                const config = this.build();
                const plugins = {};
                for (let pluginKey in config.plugins) {
                    plugins[pluginKey] = [];
                    config.plugins[pluginKey].forEach(information => {
                        const parameters = [];
                        information.parameters.forEach(value => {
                            if (value instanceof Serialization) {
                                parameters.push(value.deserialize());
                            }
                            else {
                                parameters.push(value);
                            }
                        });
                        plugins[pluginKey].push({
                            name: information.name,
                            parameters: parameters
                        });
                    });
                }
                fs.writeFileSync(filePath, JSON.stringify({
                    modules: config.modules,
                    loaders: config.loaders,
                    moduleType: config.moduleType,
                    dependencies: config.dependencies,
                    queues: config.queues,
                    plugins: plugins
                }, null, 4));
            }
        }
        exports["tsb_config_1"].QueueKind = QueueKind;
        exports["tsb_config_1"].Serialization = Serialization;
        exports["tsb_config_1"].QueueBuilder = QueueBuilder;
        exports["tsb_config_1"].ConfigBuilder = ConfigBuilder;
    }
});
bundler.register("tsb_context_2", ["tsb_types_15", "tsb_output_5", "tsb_config_1", "tsb_global_4"], (imports, exports, config) => {
    const p = require("path");
    const { Diagnostic, Node, Project, SourceFile, SyntaxKind } = require("ts-morph");
    const { set_status, write_error, write_log } = imports["tsb_output_5"];
    const { CWD } = imports["tsb_global_4"];
    const fs = require("fs");
    {
        let modules;
        function init_translation(config) {
            modules = config.modules;
        }
        function translate_to_id(module, path, dependencies) {
            if (path.startsWith("@lib/")) {
                const parts = path.split("/");
                parts.shift();
                const lib = parts.shift();
                parts.unshift(lib);
                const map = JSON.parse(fs.readFileSync(p.join(CWD, "lib", lib, lib + ".fm.json"), "utf-8"));
                return "\"" + map[parts.join("/") + ".ts"] + "\"";
            }
            if (p.extname(path) != "") {
                path = path.replace(/\.[^/.]+$/, "");
            }
            const pathWithoutExt = path = path.replace(/\\/gi, "/");
            path = path.replace(CWD.replace(/\\/gi, "/") + "/", "") + ".ts";
            if (modules[module].includes(path)) {
                return "\"" + module + "_" + p.basename(pathWithoutExt) + "_" + modules[module].indexOf(path) + "\"";
            }
            for (let dependency of dependencies) {
                if (modules[dependency].includes(path)) {
                    return "\"" + dependency + "_" + p.basename(pathWithoutExt) + "_" + modules[dependency].indexOf(path) + "\"";
                }
            }
            write_error(`ERROR: Could not map path '${path}'`);
            set_status("FAIL");
            return "\"" + module + "_undefined\"";
        }
        function get_all_translations(module) {
            let x = {};
            modules[module].forEach(value => x[value] = module + "_" + p.basename(value).replace(p.extname(value), "") + "_" + modules[module].indexOf(value));
            return x;
        }
        function find_by_name(sourceFile, name) {
            return sourceFile.getDescendantsOfKind(SyntaxKind.Identifier)
                .filter(identifier => identifier.getText() === name)
                .map(identifier => identifier.getParent())[0];
        }
        function replace_type_name(module, name, newName) {
            module.module.getDescendantsOfKind(SyntaxKind.Identifier).forEach(identifier => {
                if (identifier.getText() == name) {
                    const parent = identifier.getParent();
                    if (parent && parent.getKind() == SyntaxKind.TypeReference) {
                        identifier.replaceWithText(newName);
                    }
                }
            });
        }
        function check_diagnostics(project) {
            const diagnostics = project.getPreEmitDiagnostics();
            if (diagnostics.length == 0) {
                return true;
            }
            write_log(project.formatDiagnosticsWithColorAndContext(diagnostics));
            return false;
        }
        function compare_import(imp1, imp2) {
            if (imp1.kind != imp2.kind) {
                return false;
            }
            if (imp1.items.length != imp2.items.length) {
                return false;
            }
            let doRet = false;
            imp1.items.forEach((item1, index) => {
                const item2 = imp2.items[index];
                if (item1.name != item2.name) {
                    doRet = true;
                }
                if (item1.type != item2.type) {
                    doRet = true;
                }
            });
            if (doRet) {
                return false;
            }
            if (imp1.path != imp2.path) {
                return false;
            }
            return true;
        }
        exports["tsb_context_2"].init_translation = init_translation;
        exports["tsb_context_2"].translate_to_id = translate_to_id;
        exports["tsb_context_2"].get_all_translations = get_all_translations;
        exports["tsb_context_2"].find_by_name = find_by_name;
        exports["tsb_context_2"].replace_type_name = replace_type_name;
        exports["tsb_context_2"].check_diagnostics = check_diagnostics;
        exports["tsb_context_2"].compare_import = compare_import;
    }
});
bundler.register("tsb_engine_3", [], (imports, exports, config) => {
    const { Scope, StructureKind } = require("ts-morph");
    {
        function build_bundler_types() {
            return [
                {
                    kind: StructureKind.TypeAlias,
                    name: "BundlerImport",
                    type: "{ [key in (string)]: any }"
                },
                {
                    kind: StructureKind.TypeAlias,
                    name: "BundlerExports",
                    type: "{ [key in (string)]: any }"
                },
                {
                    kind: StructureKind.TypeAlias,
                    name: "BundlerConfig",
                    type: "{ pragma: \"once\" | \"multiple\" }"
                },
                {
                    kind: StructureKind.TypeAlias,
                    name: "BundlerModule",
                    type: "{ (imports: BundlerImport, exports: BundlerExports, config: BundlerConfig): void }"
                },
                {
                    kind: StructureKind.TypeAlias,
                    name: "BundlerStorage",
                    type: "{ config: BundlerConfig | {}; imports: string[]; module: BundlerModule; }"
                },
            ];
        }
        function build_bundler() {
            return {
                kind: StructureKind.Class,
                name: "Bundler",
                ctors: [
                    {
                        parameters: [
                            {
                                kind: StructureKind.Parameter,
                                name: "name",
                                type: "string"
                            }
                        ],
                        kind: StructureKind.Constructor,
                        statements: writer => {
                            writer.writeLine("this.modules = new Map<string, BundlerStorage>();");
                            writer.writeLine("this.loaded = new Map<string, BundlerExports>();");
                            writer.writeLine("this.name = name");
                        }
                    }
                ],
                properties: [
                    {
                        kind: StructureKind.Property,
                        name: "modules",
                        type: "Map<string, BundlerStorage>",
                        scope: Scope.Private
                    },
                    {
                        kind: StructureKind.Property,
                        name: "loaded",
                        type: "Map<string, BundlerExports>",
                        scope: Scope.Private
                    },
                    {
                        kind: StructureKind.Property,
                        name: "name",
                        type: "string",
                        scope: Scope.Private
                    }
                ],
                methods: [
                    {
                        kind: StructureKind.Method,
                        name: "register",
                        parameters: [
                            {
                                kind: StructureKind.Parameter,
                                name: "id",
                                type: "string"
                            },
                            {
                                kind: StructureKind.Parameter,
                                name: "requires",
                                type: "string[]"
                            },
                            {
                                kind: StructureKind.Parameter,
                                name: "module",
                                type: "BundlerModule"
                            }
                        ],
                        returnType: "void",
                        statements: writer => {
                            writer.writeLine("this.modules.set(id, {");
                            writer.writeLine("config: {},");
                            writer.writeLine("imports: requires,");
                            writer.writeLine("module: module");
                            writer.writeLine("});");
                        },
                        scope: Scope.Public
                    },
                    {
                        kind: StructureKind.Method,
                        name: "load",
                        parameters: [
                            {
                                kind: StructureKind.Parameter,
                                name: "items",
                                type: "string[]",
                                isRestParameter: true
                            }
                        ],
                        returnType: "void",
                        statements: writer => {
                            writer.writeLine("for (let i = 0; i < items.length; i++) {");
                            writer.writeLine("const [status] = this.loadItem(items[i]);");
                            writer.writeLine("if (!status) {");
                            writer.writeLine("return;");
                            writer.writeLine("}}");
                        },
                        scope: Scope.Public
                    },
                    {
                        kind: StructureKind.Method,
                        name: "loadItem",
                        parameters: [
                            {
                                kind: StructureKind.Parameter,
                                name: "item",
                                type: "string"
                            }
                        ],
                        returnType: "[boolean, BundlerExports]",
                        statements: writer => {
                            writer.writeLine("if (!this.modules.has(item)) {");
                            writer.writeLine('let domain: string = item.split("_")[0]');
                            writer.writeLine("if (typeof window == \"undefined\") {");
                            writer.writeLine("if (typeof global[\"domain\"] == \"undefined\") {");
                            writer.writeLine("console.error(`BUNDLER: Cannot resolve '${item}'`);");
                            writer.writeLine("return [false, []];");
                            writer.writeLine("}");
                            writer.writeLine(`if (global["domain"][domain] == "undefined") {`);
                            writer.writeLine("console.error(`BUNDLER: Cannot resolve '${item}'`);");
                            writer.writeLine("return [false, []];");
                            writer.writeLine("} else {");
                            writer.writeLine("return global[\"domain\"][domain].loadItem(item);");
                            writer.writeLine("}");
                            writer.writeLine("} else {");
                            writer.writeLine("if (typeof window[\"domain\"] == \"undefined\") {");
                            writer.writeLine("console.error(`BUNDLER: Cannot resolve '${item}'`);");
                            writer.writeLine("return [false, []];");
                            writer.writeLine("}");
                            writer.writeLine(`if (window["domain"][domain] == "undefined") {`);
                            writer.writeLine("console.error(`BUNDLER: Cannot resolve '${item}'`);");
                            writer.writeLine("return [false, []];");
                            writer.writeLine("} else {");
                            writer.writeLine("return window[\"domain\"][domain].loadItem(item);");
                            writer.writeLine("}");
                            writer.writeLine("}");
                            writer.writeLine("}");
                            writer.writeLine("if (this.loaded.has(item)) {");
                            writer.writeLine("return [true, this.loaded.get(item)];");
                            writer.writeLine("}");
                            writer.writeLine("const module: BundlerStorage = this.modules.get(item);");
                            writer.writeLine("let imports: BundlerImport = {};");
                            writer.writeLine("let exports: BundlerExports = {};");
                            writer.writeLine("exports[item] = {}");
                            writer.writeLine("let config: BundlerConfig = {");
                            writer.writeLine("pragma: \"once\"");
                            writer.writeLine("};");
                            writer.writeLine("module.imports.forEach(subitem => {");
                            writer.writeLine("const [status, exports] = this.loadItem(subitem);");
                            writer.writeLine("if (!status) {");
                            writer.writeLine("console.error(`BUNDLER: Could not load reference '${subitem}' in ${item}`);");
                            writer.writeLine("return;");
                            writer.writeLine("}");
                            writer.writeLine("imports[subitem] = exports[subitem];");
                            writer.writeLine("});");
                            writer.writeLine("module.module(imports, exports, config);");
                            writer.writeLine("if (config.pragma == \"once\") {");
                            writer.writeLine("this.loaded.set(item, exports);");
                            writer.writeLine("}");
                            writer.writeLine("return [true, exports];");
                        },
                        scope: Scope.Public
                    }
                ]
            };
        }
        exports["tsb_engine_3"].build_bundler_types = build_bundler_types;
        exports["tsb_engine_3"].build_bundler = build_bundler;
    }
});
bundler.register("tsb_global_4", [], (imports, exports, config) => {
    {
        const CWD = process.cwd();
        const ENGINE_DIR = "engine";
        const CONFIG_FILE = "tsb.config.js";
        const BUILD_OPTIONS = {
            produceTS: false,
            option: false
        };
        exports["tsb_global_4"].CWD = CWD;
        exports["tsb_global_4"].ENGINE_DIR = ENGINE_DIR;
        exports["tsb_global_4"].CONFIG_FILE = CONFIG_FILE;
        exports["tsb_global_4"].BUILD_OPTIONS = BUILD_OPTIONS;
    }
});
bundler.register("tsb_output_5", ["tsb_config_1", "tsb_global_4"], (imports, exports, config) => {
    const { Progress } = require("clui");
    const readline = require("readline");
    const { BUILD_OPTIONS } = imports["tsb_global_4"];
    {
        const PROGRESS = "🪛";
        const OK = "✅";
        const FAILURE = "❌";
        const WARNINGS = "❗";
        let Color;
        (function (Color) {
            Color[Color["Black"] = 0] = "Black";
            Color[Color["Red"] = 1] = "Red";
            Color[Color["Green"] = 2] = "Green";
            Color[Color["Yellow"] = 3] = "Yellow";
            Color[Color["Blue"] = 4] = "Blue";
            Color[Color["Magenta"] = 5] = "Magenta";
            Color[Color["Cyan"] = 6] = "Cyan";
            Color[Color["White"] = 7] = "White";
            Color[Color["Default"] = 9] = "Default";
            Color[Color["Reset"] = -1] = "Reset";
        })(Color || (Color = {}));
        const queueStatus = [];
        let active = 0;
        function init_queue_status(queue) {
            queueStatus.length = 0;
            queue.forEach((value, index) => {
                queueStatus[index] = {
                    queue: queue,
                    index: index,
                    status: "WAITING",
                    fullProgressBar: new Progress(20),
                    fullProgressValue: 0,
                    stepProgressBar: new Progress(20),
                    stepProgressValue: 0,
                    title: "",
                    statusMessage: "Waiting",
                    logs: []
                };
            });
            console.log(`Build option: '${BUILD_OPTIONS.option}'`);
            print_queue(true);
        }
        function colorize(str, fore) {
            let x = "";
            fore = fore ?? Color.Default;
            x += `\x1B[${fore == Color.Reset ? 0 : 30 + fore}m`;
            x += str;
            x += "\x1B[0m";
            return x;
        }
        function set_active(index) {
            active = index;
        }
        function set_status(status) {
            queueStatus[active].status = status;
            if (status == "OK") {
                write_status_message("Done");
            }
            if (status == "OK" || status == "WARNING") {
                set_step_value(1);
                set_full_value(1);
            }
            print_queue();
        }
        function has_status(status) {
            return queueStatus[active].status == status;
        }
        function set_step_value(value) {
            queueStatus[active].stepProgressValue = value;
            print_queue();
        }
        function set_full_value(value) {
            queueStatus[active].fullProgressValue = value;
            print_queue();
        }
        function write_status_message(message) {
            queueStatus[active].statusMessage = message;
            print_queue();
        }
        function write_title(title) {
            queueStatus[active].title = title;
            print_queue();
        }
        function write_error(error) {
            error = colorize(error, Color.Red);
            queueStatus[active].logs.push(...chop_line(error));
        }
        function write_warning(warning) {
            warning = colorize(warning, Color.Yellow);
            queueStatus[active].logs.push(...chop_line(warning));
        }
        function write_log(text) {
            queueStatus[active].logs.push(...chop_line(text));
        }
        function chop_line(line) {
            return line.split(/\r?\n/);
        }
        let lines = 0;
        function print_queue(init = false) {
            if (!init) {
                readline.cursorTo(process.stdout, 0);
                readline.moveCursor(process.stdout, 0, -lines);
            }
            lines = 0;
            let done = 0;
            let failed = 0;
            let warnings = 0;
            queueStatus.forEach(value => {
                switch (value.status) {
                    case "OK":
                        done++;
                        break;
                    case "FAIL":
                        failed++;
                        break;
                    case "WARNING":
                        warnings++;
                        done++;
                        break;
                }
                readline.clearLine(process.stdout, 0);
                process.stdout.write(value.status == "OK" ? OK :
                    value.status == "WAITING" || value.status == "DOING" ? PROGRESS :
                        value.status == "FAIL" ? FAILURE :
                            value.status == "WARNING" ? WARNINGS :
                                FAILURE);
                process.stdout.write(" ");
                process.stdout.write(value.fullProgressBar.update(value.fullProgressValue));
                process.stdout.write(" ".repeat(value.fullProgressValue == 1 ? 1 : value.fullProgressValue >= 0.1 ? 2 : 3) + value.title);
                process.stdout.write("\n");
                lines++;
                readline.clearLine(process.stdout, 0);
                process.stdout.write("   ");
                process.stdout.write(value.stepProgressBar.update(value.stepProgressValue));
                process.stdout.write(" ".repeat(value.stepProgressValue == 1 ? 1 : value.stepProgressValue >= 0.1 ? 2 : 3));
                process.stdout.write(value.statusMessage);
                lines++;
                process.stdout.write("\n");
                value.logs.forEach(value => {
                    readline.clearLine(process.stdout, 0);
                    process.stdout.write("   ");
                    process.stdout.write(value);
                    lines++;
                    process.stdout.write("\n");
                    readline.clearLine(process.stdout, 0);
                    lines++;
                    process.stdout.write("\n");
                });
                lines++;
                readline.clearLine(process.stdout, 0);
                process.stdout.write("\n");
            });
            lines++;
            readline.clearLine(process.stdout, 0);
            process.stdout.write(`${colorize(done.toString(), Color.Green)} tasks finished, ${colorize(failed.toString(), Color.Red)} failed, ${colorize(warnings.toString(), Color.Yellow)} with warnings${queueStatus.length - (done + failed) != 0 ? "," : ""}\n`);
            lines++;
            readline.clearLine(process.stdout, 0);
            if (queueStatus.length - (done + failed) != 0) {
                process.stdout.write(`${colorize((queueStatus.length - (done + failed)).toString(), Color.Cyan)} ${queueStatus.length - (done + failed) == 1 ? "is" : "are"} waiting/proceeding\n`);
            }
            else {
                process.stdout.write("\n");
            }
        }
        exports["tsb_output_5"].init_queue_status = init_queue_status;
        exports["tsb_output_5"].colorize = colorize;
        exports["tsb_output_5"].set_active = set_active;
        exports["tsb_output_5"].set_status = set_status;
        exports["tsb_output_5"].has_status = has_status;
        exports["tsb_output_5"].set_step_value = set_step_value;
        exports["tsb_output_5"].set_full_value = set_full_value;
        exports["tsb_output_5"].write_status_message = write_status_message;
        exports["tsb_output_5"].write_title = write_title;
        exports["tsb_output_5"].write_error = write_error;
        exports["tsb_output_5"].write_warning = write_warning;
        exports["tsb_output_5"].write_log = write_log;
        exports["tsb_output_5"].Color = Color;
    }
});
bundler.register("tsb_plugin_6", ["tsb_config_1", "tsb_types_15"], (imports, exports, config) => {
    const { CodeBlockWriter } = require("ts-morph");
    {
        class Plugin {
            modify(module) {
            }
            generate() {
                return [];
            }
            beforeLoad(writer, information) {
                return;
            }
            result(fileContent, information) {
                return null;
            }
            sync(information) {
                return;
            }
            pack(information) {
                return false;
            }
        }
        class PluginHandler {
            static plugins = new Map();
            static register(plugin) {
                this.plugins.set(plugin.name, plugin);
            }
            static instantiate(name, parameters) {
                if (!this.plugins.has(name)) {
                    return null;
                }
                const plugin = new (this.plugins.get(name).constructor)();
                plugin.init(parameters);
                return plugin;
            }
            static names() {
                let str = [];
                this.plugins.forEach(value => {
                    str.push(value.name);
                });
                return str.join(", ");
            }
        }
        exports["tsb_plugin_6"].Plugin = Plugin;
        exports["tsb_plugin_6"].PluginHandler = PluginHandler;
    }
});
bundler.register("tsb_structure_7", ["tsb_global_4"], (imports, exports, config) => {
    const fs = require("fs");
    const path = require("path");
    const { CWD } = imports["tsb_global_4"];
    {
        function check_dir(p) {
            if (fs.existsSync(p) && fs.statSync(p).isDirectory()) {
                return true;
            }
            return false;
        }
        function build_output() {
            if (!check_dir(path.join(CWD, "out"))) {
                fs.mkdirSync(path.join(CWD, "out"));
            }
        }
        exports["tsb_structure_7"].build_output = build_output;
    }
});
bundler.register("tsb_task_8", ["tsb_config_1", "tsb_output_5", "tsb_global_4", "tsb_utils_16", "tsb_transpiler_14", "tsb_plugin_6", "tsb_types_15", "tsb_context_2"], (imports, exports, config) => {
    const { has_status, set_full_value, set_status, set_step_value, write_error, write_status_message, write_warning } = imports["tsb_output_5"];
    const fs = require("fs");
    const path = require("path");
    const { BUILD_OPTIONS, CWD, ENGINE_DIR } = imports["tsb_global_4"];
    const { list_dirs, list_files } = imports["tsb_utils_16"];
    const { EmitOutput, OutputFile } = require("ts-morph");
    const { compile_module } = imports["tsb_transpiler_14"];
    const { Plugin, PluginHandler } = imports["tsb_plugin_6"];
    const { LibIncludeType } = imports["tsb_types_15"];
    const { init_translation } = imports["tsb_context_2"];
    const AdmZip = require("adm-zip");
    {
        function compile_module_task(config, information) {
            if (!!config.modules[information.moduleName]) {
                const name = information.moduleName;
                const sources = config.modules[information.moduleName];
                const loaders = config.loaders[information.moduleName];
                const type = config.moduleType[information.moduleName];
                const plugins = [];
                init_translation(config);
                for (let plugin of config.plugins[information.moduleName]) {
                    const component = PluginHandler.instantiate(plugin.name, plugin.parameters);
                    if (!component) {
                        write_error(`ERROR: Cannot find the plugin '${plugin.name}' found ${PluginHandler.names()}`);
                        set_status("FAIL");
                        return;
                    }
                    plugins.push(component);
                }
                const dependencyList = config.dependencies[information.moduleName] || [];
                const dependencies = [];
                dependencyList.forEach((dependency) => {
                    if (!config.modules[dependency]) {
                        write_error(`ERROR: Cannot find dependency '${dependency}'`);
                        set_status("FAIL");
                    }
                    dependencies.push(dependency);
                });
                if (has_status("FAIL")) {
                    return;
                }
                const result = compile_module(name, sources, loaders, plugins, dependencies, type);
                if (result == null) {
                    return;
                }
                set_full_value(0.84);
                if (BUILD_OPTIONS.produceTS) {
                    write_status_message("Create Typescript file");
                    fs.writeFileSync(result.sourceFile.getFilePath(), result.sourceFile.print());
                }
                else {
                    fs.unlinkSync(path.join(CWD, "out", name + ".ts"));
                }
                write_status_message("Write output");
                set_full_value(0.96);
                let output = result.sourceFile.getEmitOutput();
                let data = output.getOutputFiles().filter(value => value.getFilePath() == result.sourceFile.getFilePath().replace(path.extname(result.sourceFile.getFilePath()), ".js"))[0];
                let transformedData = data.getText().replace(/^export.*;$/gim, () => {
                    return "";
                });
                const resultInformation = {
                    outDir: path.dirname(result.sourceFile.getFilePath()),
                    outName: path.basename(data.getFilePath()),
                    outPath: data.getFilePath(),
                    engineDir: path.join(CWD, ENGINE_DIR),
                    module: name
                };
                for (let i = 0; i < plugins.length; i++) {
                    const transformed = plugins[i].result(transformedData, resultInformation);
                    if (!!transformed) {
                        transformedData = transformed;
                    }
                }
                fs.writeFileSync(data.getFilePath(), transformedData);
                set_status("OK");
                return;
            }
            write_error("ERROR: Cannot find module '" + information.moduleName + "'");
            set_status("FAIL");
        }
        function pack_module_task(config, information) {
            const zip = new AdmZip();
            write_status_message("Packing headers");
            set_step_value(0);
            set_full_value(0);
            let read = 0;
            let total = 0;
            function packHeaders(dir, vpath) {
                let entries = fs.readdirSync(dir);
                total += entries.length;
                entries.forEach((entry) => {
                    set_step_value(read / total * 100);
                    read++;
                    if (entry.endsWith(".d.ts")) {
                        zip.addLocalFile(path.join(dir, entry), vpath);
                    }
                    if (fs.statSync(path.join(dir, entry)).isDirectory()) {
                        packHeaders(path.join(dir, entry), path.join(vpath, entry));
                    }
                });
            }
            packHeaders(path.join(CWD, "out", "header", information.moduleName), "header");
            write_status_message("Packing file map");
            set_step_value(15);
            set_full_value(0);
            zip.addLocalFile(path.join(CWD, "out", "header", information.moduleName, information.moduleName + ".fm.json"), "");
            set_step_value(30);
            set_full_value(0);
            write_status_message("Packing module");
            zip.addLocalFile(path.join(CWD, "out", information.moduleName + ".js"), "");
            set_step_value(45);
            set_full_value(0);
            write_status_message("Checking Plugins");
            const libConfig = {
                name: information.moduleName,
                scripts: [],
                assets: [],
            };
            const zipPackInf = {
                outDir: path.join(CWD, "out"),
                outName: "",
                outPath: "",
                engineDir: path.join(CWD, ENGINE_DIR),
                module: information.moduleName
            };
            for (let i = 0; i < config.plugins[information.moduleName].length; i++) {
                let plugin = config.plugins[information.moduleName][i];
                set_step_value(i / config.plugins[information.moduleName].length * 100);
                const component = PluginHandler.instantiate(plugin.name, plugin.parameters);
                if (!component) {
                    write_error(`ERROR: Cannot find the plugin '${plugin.name}' found ${PluginHandler.names()}`);
                    set_status("FAIL");
                    return;
                }
                const copies = component.pack(zipPackInf);
                if (copies) {
                    copies.forEach((copy) => {
                        switch (copy.type) {
                            case LibIncludeType.ASSET:
                                if (fs.existsSync(copy.src) && fs.statSync(copy.src).isFile()) {
                                    zip.addLocalFile(path.join(CWD, copy.src), copy.vdest);
                                    libConfig.assets.push({
                                        src: path.join(copy.vdest, path.basename(copy.src)),
                                        dest: copy.dest
                                    });
                                }
                                break;
                            case LibIncludeType.SCRIPT:
                                if (fs.existsSync(copy.src) && fs.statSync(copy.src).isFile()) {
                                    zip.addLocalFile(path.join(CWD, copy.src), copy.vdest);
                                    libConfig.scripts.push(path.join(copy.vdest, path.basename(copy.src)));
                                }
                                break;
                        }
                    });
                }
            }
            write_status_message("Packing lib information");
            set_step_value(60);
            set_full_value(0);
            zip.addFile("lib.json", Buffer.from(JSON.stringify(libConfig)));
            set_step_value(75);
            set_full_value(0);
            write_status_message("Writing output");
            zip.writeZip(path.join(CWD, information.moduleName + ".lib.zip"));
            set_status("OK");
        }
        function copy_task(information) {
            if (!fs.existsSync(path.join(CWD, information.from))) {
                write_error("ERROR: Cannot find item '" + information.from + "'");
                set_status("FAIL");
                return;
            }
            if (!fs.existsSync(path.join(CWD, information.to)) || !fs.statSync(path.join(CWD, information.to)).isDirectory()) {
                write_error("ERROR: Cannot find item '" + information.to + "'");
                set_status("FAIL");
                return;
            }
            if (fs.statSync(path.join(CWD, information.from)).isFile()) {
                fs.copyFileSync(path.join(CWD, information.from), path.join(CWD, information.to, path.basename(information.from)));
                set_status("OK");
                return;
            }
            if (!fs.existsSync(path.join(CWD, information.to, path.basename(information.from))) || !fs.statSync(path.join(CWD, information.to, path.basename(information.from))).isDirectory()) {
                fs.mkdirSync(path.join(CWD, information.to, path.basename(information.from)));
            }
            write_status_message("Collecting directories");
            let dirs = list_dirs(path.join(CWD, information.from));
            write_status_message("Collecting files");
            set_full_value(0.25);
            let files = list_files(path.join(CWD, information.from));
            set_full_value(0.50);
            dirs.forEach((dir, value) => {
                set_step_value(value / dirs.length);
                write_status_message(`Create '${dir.replace(path.join(CWD, information.from), "")}'`);
                if (!fs.existsSync(dir.replace(path.join(CWD, information.from), path.join(information.to, path.basename(information.from))))) {
                    fs.mkdirSync(dir.replace(path.join(CWD, information.from), path.join(information.to, path.basename(information.from))));
                }
            });
            set_full_value(0.75);
            files.forEach((file, value) => {
                set_step_value(value / files.length);
                write_status_message(`Copy '${file.replace(path.join(CWD, information.from), "")}'`);
                if (!fs.existsSync(file.replace(path.join(CWD, information.from), information.to)) || information.overwrite) {
                    fs.copyFileSync(file, file.replace(path.join(CWD, information.from), path.join(information.to, path.basename(information.from))));
                }
            });
            set_status("OK");
        }
        function remove_task(information) {
            if (fs.existsSync(path.join(CWD, information.target))) {
                if (fs.statSync(path.join(CWD, information.target)).isFile()) {
                    fs.unlinkSync(path.join(CWD, information.target));
                    set_status("OK");
                    return;
                }
                if (fs.statSync(path.join(CWD, information.target)).isDirectory()) {
                    if (information.recursive) {
                        write_status_message("Collecting folders");
                        let dirs = list_dirs(path.join(CWD, information.target), false);
                        set_full_value(0.25);
                        write_status_message("Collecting files");
                        let files = list_files(path.join(CWD, information.target));
                        set_full_value(0.50);
                        files.forEach((file, value) => {
                            set_step_value(value / files.length);
                            write_status_message(`Removing '${file.replace(path.join(CWD, information.target), "")}'`);
                            fs.unlinkSync(file);
                        });
                        set_full_value(0.75);
                        dirs.forEach((dir, value) => {
                            set_step_value(value / dirs.length);
                            write_status_message(`Removing '${dir.replace(path.join(CWD, information.target), "")}'`);
                            fs.rmdirSync(dir);
                        });
                        set_status("OK");
                        return;
                    }
                    else {
                        set_status("FAIL");
                        write_error("ERROR: Item to remove is a folder but recursive flag is not set");
                        return;
                    }
                }
                set_status("FAIL");
                write_error("ERROR: '" + information.target + "' is not a file or a folder");
                return;
            }
            write_warning("WARNING: Could not find '" + information.target + "'");
            set_status("WARNING");
        }
        exports["tsb_task_8"].compile_module_task = compile_module_task;
        exports["tsb_task_8"].pack_module_task = pack_module_task;
        exports["tsb_task_8"].copy_task = copy_task;
        exports["tsb_task_8"].remove_task = remove_task;
    }
});
bundler.register("tsb_build_9", ["tsb_global_4", "tsb_config_1", "tsb_output_5", "tsb_utils_16", "tsb_task_8"], (imports, exports, config) => {
    const { BUILD_OPTIONS, CONFIG_FILE, CWD } = imports["tsb_global_4"];
    const path = require("path");
    const fs = require("fs");
    const { QueueKind } = imports["tsb_config_1"];
    const { Color, colorize, has_status, init_queue_status, set_active, set_status, write_title } = imports["tsb_output_5"];
    const { shift } = imports["tsb_utils_16"];
    const { compile_module_task, copy_task, pack_module_task, remove_task } = imports["tsb_task_8"];
    {
        function prebuild() {
            let arg = null;
            while (typeof (arg = shift()) == "string") {
                if (arg == "--write-ts") {
                    BUILD_OPTIONS.produceTS = true;
                }
                else {
                    BUILD_OPTIONS.option = arg;
                }
            }
            const configPath = path.join(CWD, CONFIG_FILE);
            if (!fs.existsSync(configPath) || !fs.statSync(configPath).isFile()) {
                console.log(colorize("ERROR: Cannot find 'tsb.config.js'. Are you in the right directory?", Color.Red));
                process.exit(1);
            }
            let config = require(path.join(CWD, CONFIG_FILE)).default;
            if (config == null) {
                console.log(colorize("ERROR: No config object is exported as default", Color.Red));
                process.exit(1);
            }
            if (!BUILD_OPTIONS.option) {
                if (Object.keys(config.queues).length < 1) {
                    console.log(colorize("ERROR: No option is declared", Color.Red));
                    process.exit(1);
                }
                BUILD_OPTIONS.option = Object.keys(config.queues)[0];
            }
            return config;
        }
        function build() {
            const config = prebuild();
            const queue = config.queues[BUILD_OPTIONS.option];
            if (!queue) {
                console.log(colorize(`ERROR: The option '${BUILD_OPTIONS.option}' is not declared in your config file`, Color.Red));
                process.exit(1);
            }
            init_queue_status(queue);
            queue.forEach((value, index) => {
                set_active(index);
                if (value.kind == QueueKind.COMPILE_MODULE) {
                    write_title(`Compile '${value.information.moduleName}'`);
                }
                else if (value.kind == QueueKind.COPY) {
                    write_title(`Copy '${value.information.from}'`);
                }
                else if (value.kind == QueueKind.REMOVE) {
                    write_title(`Remove '${value.information.target}'`);
                }
                else if (value.kind == QueueKind.PACK) {
                    write_title(`Pack '${value.information.moduleName}'`);
                }
            });
            let hasErrors = false;
            queue.forEach((value, index) => {
                set_active(index);
                set_status("DOING");
                if (value.kind == QueueKind.COMPILE_MODULE) {
                    const information = value.information;
                    compile_module_task(config, information);
                }
                else if (value.kind == QueueKind.COPY) {
                    const information = value.information;
                    copy_task(information);
                }
                else if (value.kind == QueueKind.REMOVE) {
                    const information = value.information;
                    remove_task(information);
                }
                else if (value.kind == QueueKind.PACK) {
                    const information = value.information;
                    pack_module_task(config, information);
                }
                if (!hasErrors) {
                    hasErrors = has_status("FAIL");
                }
            });
            process.exit(hasErrors ? 1 : 0);
        }
        exports["tsb_build_9"].default = build;
    }
});
bundler.register("tsb_init_10", ["tsb_transpiler_14", "tsb_global_4", "tsb_plugin_6", "tsb_use_13"], (imports, exports, config) => {
    const { OPTIONS_JSX, OPTIONS_MODULE_KIND, OPTIONS_SCRIPT_TARGET } = imports["tsb_transpiler_14"];
    const fs = require("fs");
    const path = require("path");
    const { CWD, ENGINE_DIR } = imports["tsb_global_4"];
    const { PluginHandler } = imports["tsb_plugin_6"];
    const AdmZip = require("adm-zip");
    const { extract_file } = imports["tsb_use_13"];
    {
        function make_folder(dir) {
            if (!fs.existsSync(dir) || !fs.statSync(dir).isDirectory()) {
                fs.mkdirSync(dir);
            }
        }
        function generate_plugin_file(plugins) {
            const obj = {};
            plugins.forEach(plugin => {
                const parts = plugin.split(".");
                const each = (remain, obj) => {
                    if (remain.length == 1) {
                        obj[remain.shift().toUpperCase()] = plugin;
                        return;
                    }
                    const part = remain.shift();
                    if (!obj[part.toUpperCase()]) {
                        obj[part.toUpperCase()] = {};
                    }
                    each(remain, obj[part.toUpperCase()]);
                };
                each(parts, obj);
            });
            const to_string = (obj, space, last) => {
                let str = "{\n";
                space += 4;
                Object.keys(obj).forEach((key, index, array) => {
                    if (typeof obj[key] == "object") {
                        str += " ".repeat(space) + key + ": ";
                        str += to_string(obj[key], space, index == array.length - 1);
                    }
                    else {
                        str += " ".repeat(space) + key + `: "${obj[key]}"` + (index == array.length - 1 ? "\n" : ",\n");
                    }
                });
                space -= 4;
                str += " ".repeat(space) + "}" + (last ? "\n" : ",\n");
                return str;
            };
            return {
                ts: `export declare const PLUGINS: ${to_string(obj, 0, true)}`,
                js: `"use strict"\nObject.defineProperty(exports, "__esModule", { value: true });\nexports.PLUGINS = ${to_string(obj, 0, true)}`
            };
        }
        function init() {
            const pluginProject = process.argv.includes("--plugin") || process.argv.includes("-p");
            fs.writeFileSync(path.join(CWD, "tsconfig.json"), JSON.stringify({
                compilerOptions: {
                    module: OPTIONS_MODULE_KIND,
                    moduleResolution: "Node",
                    removeComments: true,
                    target: OPTIONS_SCRIPT_TARGET,
                    allowJs: false,
                    lib: [
                        "ES2022",
                        "DOM"
                    ],
                    paths: {
                        "@tsb/engine": [
                            "./engine/engine.d.ts"
                        ],
                        "@lib/*": [
                            "./lib/*.d.ts"
                        ]
                    }
                },
                exclude: [
                    "node_modules",
                    "out"
                ]
            }, null, 4));
            make_folder("lib");
            make_folder(ENGINE_DIR);
            fs.copyFileSync(path.join(__dirname, "assets", "config.d.ts"), path.join(CWD, ENGINE_DIR, "config.d.ts"));
            fs.copyFileSync(path.join(__dirname, "assets", "config.js"), path.join(CWD, ENGINE_DIR, "config.js"));
            fs.copyFileSync(path.join(__dirname, "assets", "engine.d.ts"), path.join(CWD, ENGINE_DIR, "engine.d.ts"));
            fs.copyFileSync(path.join(__dirname, "assets", "engine.d.ts"), path.join(CWD, ENGINE_DIR, "engine.d.ts"));
            if (pluginProject) {
                fs.writeFileSync(path.join(CWD, "tsb.config.js"), fs.readFileSync(path.join(__dirname, "assets", "plugin.config.js"), "utf8").replace(/<@OUTPUT@>/gi, path.join(__dirname, "plugins").replace(/\\/gi, "/")));
            }
            else {
                fs.copyFileSync(path.join(__dirname, "assets", "tsb.config.js"), path.join(CWD, "tsb.config.js"));
            }
            const plugins = generate_plugin_file(PluginHandler.names().split(", "));
            fs.writeFileSync(path.join(CWD, ENGINE_DIR, "plugins.d.ts"), plugins.ts);
            fs.writeFileSync(path.join(CWD, ENGINE_DIR, "plugins.js"), plugins.js);
            if (pluginProject) {
                const zip = new AdmZip(path.join(__dirname, "assets", "tsb.lib.zip"));
                extract_file(zip);
            }
        }
        exports["tsb_init_10"].default = init;
    }
});
bundler.register("tsb_pack_11", ["tsb_global_4", "tsb_output_5", "tsb_config_1", "tsb_utils_16", "tsb_task_8"], (imports, exports, config) => {
    const path = require("path");
    const { BUILD_OPTIONS, CONFIG_FILE, CWD } = imports["tsb_global_4"];
    const fs = require("fs");
    const { Color, colorize, has_status, init_queue_status, set_active, set_status, write_title } = imports["tsb_output_5"];
    const { QueueKind } = imports["tsb_config_1"];
    const { shift } = imports["tsb_utils_16"];
    const { compile_module_task, pack_module_task } = imports["tsb_task_8"];
    {
        function prepack() {
            let arg = null;
            while (typeof (arg = shift()) == "string") {
                BUILD_OPTIONS.option = arg;
            }
            const configPath = path.join(CWD, CONFIG_FILE);
            if (!fs.existsSync(configPath) || !fs.statSync(configPath).isFile()) {
                console.log(colorize("ERROR: Cannot find 'tsb.config.js'. Are you in the right directory?", Color.Red));
                process.exit(1);
            }
            let config = require(path.join(CWD, CONFIG_FILE)).default;
            if (config == null) {
                console.log(colorize("ERROR: No config object is exported as default", Color.Red));
                process.exit(1);
            }
            if (!BUILD_OPTIONS.option) {
                console.log(colorize("ERROR: No module declared", Color.Red));
                process.exit(1);
            }
            if (!Object.keys(config.modules).includes(BUILD_OPTIONS.option)) {
                console.log(colorize(`ERROR: Module '${BUILD_OPTIONS.option}' is not defined`, Color.Red));
                process.exit(1);
            }
            if (config.moduleType[BUILD_OPTIONS.option] != "lib") {
                console.log(colorize(`ERROR: Module '${BUILD_OPTIONS.option}' is not a libary`, Color.Red));
                process.exit(1);
            }
            return config;
        }
        function pack() {
            const config = prepack();
            const queue = [
                {
                    kind: QueueKind.COMPILE_MODULE,
                    information: {
                        moduleName: BUILD_OPTIONS.option
                    }
                },
                {
                    kind: QueueKind.PACK,
                    information: {
                        moduleName: BUILD_OPTIONS.option
                    }
                }
            ];
            init_queue_status(queue);
            set_active(1);
            write_title(`Pack '${queue[0].information.moduleName}'`);
            set_active(0);
            write_title(`Compile '${queue[0].information.moduleName}'`);
            set_status("DOING");
            compile_module_task(config, queue[0].information);
            if (has_status("FAIL")) {
                set_active(1);
                set_status("FAIL");
                process.exit(1);
            }
            set_active(1);
            set_status("DOING");
            pack_module_task(config, queue[1].information);
        }
        exports["tsb_pack_11"].default = pack;
    }
});
bundler.register("tsb_sync_12", ["tsb_global_4", "tsb_config_1", "tsb_output_5", "tsb_task_8", "tsb_plugin_6"], (imports, exports, config) => {
    const path = require("path");
    const { BUILD_OPTIONS, CONFIG_FILE, CWD, ENGINE_DIR } = imports["tsb_global_4"];
    const fs = require("fs");
    const { QueueKind } = imports["tsb_config_1"];
    const { Color, colorize, has_status, init_queue_status, set_active, set_status, write_error } = imports["tsb_output_5"];
    const { copy_task, remove_task } = imports["tsb_task_8"];
    const { Plugin, PluginHandler } = imports["tsb_plugin_6"];
    {
        function sync() {
            const configPath = path.join(CWD, CONFIG_FILE);
            if (!fs.existsSync(configPath) || !fs.statSync(configPath).isFile()) {
                console.log(colorize("ERROR: Cannot find 'tsb.config.js'. Are you in the right directory?", Color.Red));
                process.exit(1);
            }
            let config = require(path.join(CWD, CONFIG_FILE)).default;
            if (config == null) {
                console.log(colorize("ERROR: No config object is exported as default", Color.Red));
                process.exit(1);
                return;
            }
            if (!BUILD_OPTIONS.option) {
                if (Object.keys(config.queues).length < 1) {
                    console.log(colorize("ERROR: No option is declared", Color.Red));
                    process.exit(1);
                }
                BUILD_OPTIONS.option = Object.keys(config.queues)[0];
            }
            let queue = config.queues[BUILD_OPTIONS.option];
            if (!queue) {
                console.log(colorize(`ERROR: The option '${BUILD_OPTIONS.option}' is not declared in your config file`, Color.Red));
                process.exit(1);
            }
            queue = queue.filter(value => value.kind != QueueKind.COMPILE_MODULE && value.kind != QueueKind.PACK);
            queue.unshift({
                kind: QueueKind.SYNC_PLUGIN,
                information: {}
            });
            init_queue_status(queue);
            let hasErrors = false;
            queue.forEach((value, index) => {
                set_active(index);
                if (value.kind == QueueKind.SYNC_PLUGIN) {
                    const seenPlugins = [];
                    const information = {
                        outDir: path.join(CWD, "out"),
                        outName: "",
                        outPath: "",
                        engineDir: path.join(CWD, ENGINE_DIR),
                        module: ""
                    };
                    for (let module in config.modules) {
                        information.module = module;
                        for (let plugin of config.plugins[module]) {
                            if (seenPlugins.includes(plugin.name)) {
                                continue;
                            }
                            const component = PluginHandler.instantiate(plugin.name, plugin.parameters);
                            if (!component) {
                                write_error(`ERROR: Cannot find the plugin '${plugin.name}' found ${PluginHandler.names()}`);
                                set_status("FAIL");
                                hasErrors = true;
                                return;
                            }
                            component.sync(information);
                            seenPlugins.push(component.name);
                        }
                    }
                }
                else if (value.kind == QueueKind.COPY) {
                    const information = value.information;
                    copy_task(information);
                }
                else if (value.kind == QueueKind.REMOVE) {
                    const information = value.information;
                    remove_task(information);
                }
                if (!hasErrors) {
                    hasErrors = has_status("FAIL");
                }
            });
            process.exit(hasErrors ? 1 : 0);
        }
        exports["tsb_sync_12"].default = sync;
    }
});
bundler.register("tsb_use_13", ["tsb_utils_16", "tsb_global_4", "tsb_output_5", "tsb_types_15"], (imports, exports, config) => {
    const AdmZip = require("adm-zip");
    const fs = require("fs");
    const { shift } = imports["tsb_utils_16"];
    const { BUILD_OPTIONS, CWD } = imports["tsb_global_4"];
    const { Color, colorize } = imports["tsb_output_5"];
    const path = require("path");
    const https = require("https");
    {
        function preuse() {
            let arg = null;
            while (typeof (arg = shift()) == "string") {
                BUILD_OPTIONS.option = arg;
            }
        }
        function use() {
            preuse();
            if (!BUILD_OPTIONS.option) {
                return;
            }
            if (BUILD_OPTIONS.option.startsWith("http://") || BUILD_OPTIONS.option.startsWith("https://")) {
                console.log("Try downloading file");
                https.get(BUILD_OPTIONS.option, (res) => {
                    const buffers = [];
                    res.on('readable', function () {
                        for (;;) {
                            let buffer = res.read();
                            if (!buffer) {
                                break;
                            }
                            buffers.push(buffer);
                        }
                    });
                    res.on('end', function () {
                        const buffer = Buffer.concat(buffers);
                        const zip = new AdmZip(buffer);
                        extract_file(zip);
                    });
                });
                return;
            }
            else if (!fs.existsSync(BUILD_OPTIONS.option) || !fs.statSync(BUILD_OPTIONS.option).isFile()) {
                console.log(colorize(`ERROR: File '${BUILD_OPTIONS.option}' dont exists`, Color.Red));
                process.exit(1);
            }
            const zip = new AdmZip(BUILD_OPTIONS.option);
            extract_file(zip);
        }
        function extract_file(zip) {
            try {
                function copy_folder(dir, dest) {
                    if (!fs.existsSync(dest)) {
                        fs.mkdirSync(dest);
                    }
                    fs.readdirSync(dir).forEach((entry) => {
                        if (fs.statSync(path.join(dir, entry)).isFile()) {
                            fs.copyFileSync(path.join(dir, entry), path.join(dest, entry));
                        }
                        else if (fs.statSync(path.join(dir, entry)).isDirectory()) {
                            copy_folder(path.join(dir, entry), path.join(dest, entry));
                        }
                    });
                }
                if (!fs.existsSync(path.join(CWD, "lib"))) {
                    fs.mkdirSync(path.join(CWD, "lib"));
                }
                zip.extractAllTo(path.join(CWD, "cash"));
                const lib = JSON.parse(fs.readFileSync(path.join(CWD, "cash", "lib.json"), "utf-8"));
                if (!fs.existsSync(path.join(CWD, "lib", lib.name))) {
                    fs.mkdirSync(path.join(CWD, "lib", lib.name));
                }
                fs.copyFileSync(path.join(CWD, "cash", lib.name + ".js"), path.join(CWD, "lib", lib.name, lib.name + ".js"));
                lib.scripts.forEach((script) => {
                    fs.copyFileSync(path.join(CWD, "cash", script), path.join(CWD, "lib", lib.name, path.basename(script)));
                });
                lib.assets.forEach((asset) => {
                    if (!fs.existsSync(path.join(CWD, asset.dest)) || !fs.statSync(path.join(CWD, asset.dest)).isDirectory()) {
                        fs.mkdirSync(path.join(CWD, asset.dest), { recursive: true });
                    }
                    fs.copyFileSync(path.join(CWD, "cash", asset.src), path.join(CWD, asset.dest, path.basename(asset.src)));
                });
                fs.copyFileSync(path.join(CWD, "cash", lib.name + ".fm.json"), path.join(CWD, "lib", lib.name, lib.name + ".fm.json"));
                copy_folder(path.join(CWD, "cash", "header"), path.join(CWD, "lib", lib.name));
            }
            catch {
                console.log("Library is corrupted");
            }
        }
        exports["tsb_use_13"].default = use;
        exports["tsb_use_13"].extract_file = extract_file;
    }
});
bundler.register("tsb_transpiler_14", ["tsb_context_2", "tsb_global_4", "tsb_engine_3", "tsb_structure_7", "tsb_types_15", "tsb_output_5", "tsb_plugin_6", "tsb_config_1"], (imports, exports, config) => {
    const { ClassDeclaration, EnumDeclaration, Expression, FunctionDeclaration, Identifier, ImportSpecifier, InterfaceDeclaration, ModuleKind, ModuleResolutionKind, Project, ScriptTarget, SourceFile, SyntaxKind, TypeAliasDeclaration, VariableDeclaration, VariableDeclarationList, VariableStatement } = require("ts-morph");
    const path = require("path");
    const { check_diagnostics, get_all_translations, replace_type_name, translate_to_id } = imports["tsb_context_2"];
    const fs = require("fs");
    const { CWD, ENGINE_DIR } = imports["tsb_global_4"];
    const { build_bundler, build_bundler_types } = imports["tsb_engine_3"];
    const { build_output } = imports["tsb_structure_7"];
    const { ImportKind, SymbolType } = imports["tsb_types_15"];
    const { set_full_value, set_status, set_step_value, write_status_message } = imports["tsb_output_5"];
    const { Plugin } = imports["tsb_plugin_6"];
    {
        const OPTIONS_MODULE_KIND = "ES2022";
        const OPTIONS_SCRIPT_TARGET = "ES2022";
        const OPTIONS_JSX = "React";
        const OPTIONS = {
            module: ModuleKind[OPTIONS_MODULE_KIND],
            moduleResolution: ModuleResolutionKind.NodeJs,
            removeComments: true,
            target: ScriptTarget[OPTIONS_SCRIPT_TARGET],
            strict: false,
            allowJs: false,
            paths: {
                "@tsb/engine": [
                    "./engine/engine.d.ts"
                ],
                "@lib/*": [
                    "./lib/*.d.ts"
                ]
            }
        };
        function convert_type(kind) {
            if (typeof kind == "number") {
                if (kind == SyntaxKind.EnumDeclaration) {
                    return SymbolType.ENUM;
                }
                if (kind == SyntaxKind.InterfaceDeclaration) {
                    return SymbolType.INTERFACE;
                }
                if (kind == SyntaxKind.FunctionDeclaration) {
                    return SymbolType.FUNCTION;
                }
                if (kind == SyntaxKind.ClassDeclaration) {
                    return SymbolType.CLASS;
                }
                if (kind == SyntaxKind.TypeAliasDeclaration) {
                    return SymbolType.TYPE_ALIAS;
                }
                if (kind == SyntaxKind.VariableDeclaration) {
                    return SymbolType.VARIABLE;
                }
            }
            else {
                switch (kind) {
                    case "type":
                    case "alias":
                        return SymbolType.TYPE_ALIAS;
                    case "class":
                        return SymbolType.CLASS;
                    case "interface":
                    case "module":
                        return SymbolType.INTERFACE;
                    case "enum":
                        return SymbolType.ENUM;
                    case "function":
                        return SymbolType.FUNCTION;
                    case "var":
                    case "const":
                    case "let":
                        return SymbolType.VARIABLE;
                }
            }
            throw "Unexpected input " + kind;
        }
        function is_meta_data(type) {
            switch (type) {
                case SymbolType.INTERFACE:
                case SymbolType.TYPE_ALIAS:
                    return true;
                case SymbolType.CLASS:
                case SymbolType.ENUM:
                case SymbolType.FUNCTION:
                case SymbolType.VARIABLE:
                    return false;
            }
        }
        function cnstr_project() {
            let project = new Project({
                compilerOptions: OPTIONS,
                skipAddingFilesFromTsConfig: true
            });
            project.getSourceFiles().forEach(value => project.removeSourceFile(value));
            return project;
        }
        function add_module_item(project, source) {
            let module = project.addSourceFileAtPath(source);
            return {
                rawFilename: source,
                filename: module.getFilePath(),
                module: module
            };
        }
        function remove_imports(module) {
            module.module.getImportDeclarations().forEach(node => {
                if (node.isKind(SyntaxKind.ImportDeclaration)) {
                    node.remove();
                }
            });
        }
        const SAVE_IMPORTS = new Map();
        function extract_imports(module, generateNew = false) {
            if (SAVE_IMPORTS.has(module) && !generateNew) {
                return SAVE_IMPORTS.get(module);
            }
            const imports = [];
            module.module.getImportDeclarations().forEach((node) => {
                let modified = false;
                let importPath = node.getModuleSpecifierValue().startsWith(".") ?
                    path.join(path.dirname(module.filename), node.getModuleSpecifierValue()) :
                    node.getModuleSpecifierValue();
                const from = node.getModuleSpecifierValue().startsWith(".") || node.getModuleSpecifierValue().startsWith("@lib/") ? "FILE" : "MODULE";
                if (importPath.startsWith("@tsb/")) {
                    return;
                }
                if (!!node.getDefaultImport()) {
                    modified = true;
                    const imp = node.getDefaultImport();
                    imports.push({
                        kind: ImportKind.DEFAULT,
                        items: [{
                                name: node.getModuleSpecifierSourceFile()?.getDefaultExportSymbol()?.getName() ?? imp.getText(),
                                alias: imp.getText(),
                                type: convert_type(imp.getDefinitions()[0].getKind())
                            }],
                        path: importPath,
                        from: from
                    });
                }
                if (!!node.getNamespaceImport()) {
                    modified = true;
                    const imp = node.getNamespaceImport();
                    imports.push({
                        kind: ImportKind.NAMESPACE,
                        items: [{
                                name: imp.getText(),
                                alias: imp.getText(),
                                type: convert_type(imp.getDefinitions()[0].getKind())
                            }],
                        path: importPath,
                        from: from
                    });
                }
                if (node.getNamedImports().length != 0) {
                    modified = true;
                    const imp = node.getNamedImports();
                    const items = [];
                    imp.forEach(value => {
                        items.push({
                            name: value.getName(),
                            alias: value.getAliasNode()?.getText() ?? value.getName(),
                            type: convert_type(value.getNameNode().getDefinitions()[0].getKind())
                        });
                    });
                    imports.push({
                        kind: ImportKind.NAMED,
                        items: items,
                        path: importPath,
                        from: from
                    });
                }
                if (!modified) {
                    imports.push({
                        kind: ImportKind.INCLUDE,
                        items: [],
                        path: importPath,
                        from: from
                    });
                }
            });
            SAVE_IMPORTS.set(module, imports);
            return imports;
        }
        const SAVE_EXPORTS = new Map();
        function extract_exports(module) {
            if (SAVE_EXPORTS.has(module)) {
                return SAVE_EXPORTS.get(module);
            }
            const exports = [];
            const declarations = module.module.getExportedDeclarations();
            for (let [name, decs] of declarations) {
                let dec = decs[0];
                let local = name;
                if (!(dec instanceof Expression)) {
                    local = local == "default" ? dec.getStructure().name : local;
                }
                exports.push({
                    from: dec.getSourceFile().getFilePath() == module.filename ? "" : dec.getSourceFile().getFilePath(),
                    local: local,
                    global: name,
                    type: convert_type(dec.getKind())
                });
            }
            SAVE_EXPORTS.set(module, exports);
            return exports;
        }
        function remove_exports(module) {
            module.module.getExportedDeclarations().forEach((value) => {
                let declaration = value[0];
                if (declaration instanceof VariableDeclaration) {
                    declaration.getParent().getParent().setIsExported(false);
                }
                else if (declaration instanceof ClassDeclaration) {
                    declaration.setIsExported(false);
                }
                else if (declaration instanceof InterfaceDeclaration) {
                    declaration.setIsExported(false);
                }
                else if (declaration instanceof EnumDeclaration) {
                    declaration.setIsExported(false);
                }
                else if (declaration instanceof FunctionDeclaration) {
                    declaration.setIsExported(false);
                }
                else if (declaration instanceof TypeAliasDeclaration) {
                    declaration.setIsExported(false);
                }
            });
            module.module.getExportAssignments().forEach((value) => {
                value.remove();
            });
            module.module.removeDefaultExport();
        }
        function add_lib_files(project) {
            function loop(dir) {
                fs.readdirSync(dir).forEach((entry) => {
                    const entryPath = path.join(dir, entry);
                    if (fs.statSync(entryPath).isDirectory()) {
                        loop(entryPath);
                    }
                    else if (fs.statSync(entryPath).isFile() && entry.endsWith(".d.ts")) {
                        project.addSourceFileAtPath(entryPath);
                    }
                });
            }
            loop(path.join(CWD, "lib"));
        }
        function compile_module(name, sources, loaders, plugins, dependencies, type) {
            set_full_value(0.12);
            write_status_message("Build output");
            build_output();
            set_full_value(0.24);
            write_status_message("Init new module");
            let project = cnstr_project();
            let modules = new Array(sources.length);
            for (let i = 0; i < sources.length; i++) {
                set_step_value(i / sources.length);
                write_status_message(`Add '${sources[i]}' to module`);
                modules[i] = add_module_item(project, sources[i]);
            }
            add_lib_files(project);
            set_full_value(0.36);
            write_status_message("Check diagnostics");
            if (!check_diagnostics(project)) {
                set_status("FAIL");
                return null;
            }
            fs.writeFileSync(path.join(CWD, "out", name + ".ts"), "");
            let result = project.addSourceFileAtPath(path.join(CWD, "out", name + ".ts"));
            set_full_value(0.48);
            write_status_message("Compile engine");
            result.addTypeAliases(build_bundler_types());
            result.addClass(build_bundler());
            result.addStatements(writer => {
                writer.writeLine(`const bundler: Bundler = new Bundler("${name}");`);
                writer.writeLine("if (typeof window == \"undefined\") {");
                writer.writeLine("    if (typeof global[\"domain\"] == \"undefined\") {");
                writer.writeLine("        global[\"domain\"] = {};");
                writer.writeLine("    }");
                writer.writeLine(`    global["domain"]["${name}"] = bundler;`);
                writer.writeLine("} else {");
                writer.writeLine("    if (typeof window[\"domain\"] == \"undefined\") {");
                writer.writeLine("        window[\"domain\"] = {};");
                writer.writeLine("    }");
                writer.writeLine(`    window["domain"]["${name}"] = bundler;`);
                writer.writeLine("}");
            });
            for (let i = 0; i < plugins.length; i++) {
                result.addClasses(plugins[i].generate());
            }
            for (let i = 0; i < modules.length; i++) {
                set_step_value(i / modules.length);
                write_status_message(`Extract type data in ${modules[i].rawFilename}`);
                const imports = extract_imports(modules[i]);
                const namespaceName = translate_to_id(name, modules[i].filename, dependencies).slice(1, -1);
                imports.forEach(imp => {
                    if (imp.from != "FILE") {
                        return;
                    }
                    imp.items.forEach(item => {
                        if (is_meta_data(item.type)) {
                            replace_type_name(modules[i], item.alias, translate_to_id(name, imp.path, dependencies).slice(1, -1) + "." + item.name);
                        }
                    });
                });
                result.addStatements(writer => {
                    if (modules[i].module.getInterfaces().length == 0 && modules[i].module.getTypeAliases().length == 0) {
                        return;
                    }
                    writer.writeLine(`namespace ${namespaceName} {`);
                    modules[i].module.getInterfaces().forEach(value => {
                        value.setIsExported(true);
                        writer.writeLine(value.getFullText());
                        replace_type_name(modules[i], value.getName(), namespaceName + "." + value.getName());
                        value.remove();
                    });
                    modules[i].module.getTypeAliases().forEach(value => {
                        value.setIsExported(true);
                        writer.writeLine(value.getFullText());
                        replace_type_name(modules[i], value.getName(), namespaceName + "." + value.getName());
                        value.remove();
                    });
                    writer.writeLine("}");
                });
            }
            for (let i = 0; i < modules.length; i++) {
                for (let k = 0; k < plugins.length; k++) {
                    plugins[k].modify(modules[i]);
                }
            }
            set_full_value(0.60);
            for (let i = 0; i < modules.length; i++) {
                set_step_value(i / modules.length);
                write_status_message(`Convert '${modules[i].rawFilename}' to module item`);
                const imports = extract_imports(modules[i]);
                const exports = extract_exports(modules[i]);
                remove_imports(modules[i]);
                remove_exports(modules[i]);
                result.addStatements(writer => {
                    writer.writeLine("bundler.register(");
                    writer.writeLine(translate_to_id(name, modules[i].filename, dependencies) + ",");
                    let ids = [];
                    imports.forEach(value => {
                        if (value.from != "MODULE" && !ids.includes(translate_to_id(name, value.path, dependencies))) {
                            ids.push(translate_to_id(name, value.path, dependencies));
                        }
                    });
                    writer.writeLine("[" + ids.join(",") + "],");
                    writer.writeLine("(imports: BundlerImport, exports: BundlerExports, config: BundlerConfig): void => {");
                    imports.forEach(value => {
                        switch (value.kind) {
                            case ImportKind.DEFAULT:
                                if (is_meta_data(value.items[0].type)) {
                                    return;
                                }
                                writer.write("const ");
                                writer.write(value.items[0].alias);
                                if (value.from == "MODULE") {
                                    writer.writeLine(` = require["${value.path}").default;`);
                                }
                                else {
                                    writer.writeLine(` = imports[${translate_to_id(name, value.path, dependencies)}].default;`);
                                }
                                break;
                            case ImportKind.NAMED:
                                let c = 0;
                                for (let item of value.items) {
                                    if (!is_meta_data(item.type)) {
                                        c++;
                                    }
                                }
                                if (c == 0) {
                                    return;
                                }
                                writer.write("const {");
                                let f = true;
                                for (let item of value.items) {
                                    if (is_meta_data(item.type)) {
                                        continue;
                                    }
                                    if (!f) {
                                        writer.write(", ");
                                    }
                                    writer.write(item.name);
                                    f = false;
                                }
                                writer.write("} = ");
                                if (value.from == "MODULE") {
                                    writer.writeLine(`require("${value.path}");`);
                                }
                                else {
                                    writer.writeLine(`imports[${translate_to_id(name, value.path, dependencies)}];`);
                                }
                                for (let item of value.items) {
                                    if (is_meta_data(item.type) || item.name == item.alias) {
                                        continue;
                                    }
                                    writer.writeLine(`const ${item.alias} = ${item.name}`);
                                }
                                break;
                            case ImportKind.NAMESPACE:
                                writer.write("const ");
                                writer.write(value.items[0].name);
                                writer.write(" = ");
                                if (value.from == "MODULE") {
                                    writer.writeLine(`require("${value.path}");`);
                                }
                                else {
                                    writer.writeLine(`imports[${translate_to_id(name, value.path, dependencies)}];`);
                                }
                                break;
                            case ImportKind.INCLUDE:
                                if (value.from == "MODULE") {
                                    writer.writeLine(`require("${value.path}");`);
                                }
                                break;
                        }
                    });
                    writer.writeLine("{");
                    writer.writeLine(modules[i].module.getFullText());
                    exports.forEach(value => {
                        if (!is_meta_data(value.type)) {
                            writer.writeLine(`exports[${translate_to_id(name, modules[i].filename, dependencies)}].${value.global} = ${value.local};`);
                        }
                    });
                    writer.writeLine("}");
                    writer.writeLine("});");
                });
            }
            result.addStatements(writer => {
                plugins.forEach(plugin => {
                    const information = {
                        outDir: path.dirname(result.getFilePath()),
                        outName: path.basename(result.getFilePath()),
                        outPath: result.getFilePath(),
                        engineDir: path.join(CWD, ENGINE_DIR),
                        module: name
                    };
                    plugin.beforeLoad(writer, information);
                });
            });
            set_full_value(0.72);
            if (loaders.length > 0) {
                result.addStatements(writer => {
                    writer.writeLine("bundler.load(");
                    loaders.forEach((value, index) => {
                        set_step_value(index / loaders.length);
                        write_status_message(`Add loader of item '${translate_to_id(name, path.join(CWD, value), dependencies)}'`);
                        if (index != 0) {
                            writer.writeLine(", ");
                        }
                        writer.write(translate_to_id(name, path.join(CWD, value), dependencies));
                    });
                    writer.writeLine("");
                    writer.writeLine(");");
                });
            }
            modules.forEach(value => {
                project.removeSourceFile(value.module);
            });
            if (type == "lib") {
                compile_header(name, sources);
            }
            return {
                name: name,
                sourceFile: result,
                file_map: get_all_translations(name)
            };
        }
        function compile_header(moduleName, sources) {
            const project = cnstr_project();
            sources.forEach((source) => {
                project.addSourceFileAtPath(source);
            });
            project.compilerOptions.set({
                declaration: true,
            });
            const result = project.emitToMemory({ emitOnlyDtsFiles: true }).getFiles();
            const old_file_map = get_all_translations(moduleName);
            const file_map = {};
            result.forEach((file) => {
                const source = file.filePath.replace(CWD.replace(/\\/gi, "/") + "/", "").replace(".d.ts", ".ts");
                if (sources.includes(source)) {
                    let shorted = file.filePath.replace(CWD.replace(/\\/gi, "/") + "/", "");
                    let parts = shorted.split("/");
                    parts.shift();
                    const out = path.join(CWD, "out", "header", moduleName, ...parts);
                    fs.mkdirSync(path.dirname(out), { recursive: true });
                    fs.writeFileSync(out, file.text);
                    file_map[path.join(moduleName, ...parts).replace(".d.ts", ".ts").replace(/\\/gi, "/")] = old_file_map[source];
                }
            });
            fs.writeFileSync(path.join(CWD, "out", "header", moduleName, moduleName + ".fm.json"), JSON.stringify(file_map));
        }
        exports["tsb_transpiler_14"].is_meta_data = is_meta_data;
        exports["tsb_transpiler_14"].cnstr_project = cnstr_project;
        exports["tsb_transpiler_14"].add_module_item = add_module_item;
        exports["tsb_transpiler_14"].remove_imports = remove_imports;
        exports["tsb_transpiler_14"].extract_imports = extract_imports;
        exports["tsb_transpiler_14"].extract_exports = extract_exports;
        exports["tsb_transpiler_14"].remove_exports = remove_exports;
        exports["tsb_transpiler_14"].compile_module = compile_module;
        exports["tsb_transpiler_14"].OPTIONS_MODULE_KIND = OPTIONS_MODULE_KIND;
        exports["tsb_transpiler_14"].OPTIONS_SCRIPT_TARGET = OPTIONS_SCRIPT_TARGET;
        exports["tsb_transpiler_14"].OPTIONS_JSX = OPTIONS_JSX;
        exports["tsb_transpiler_14"].OPTIONS = OPTIONS;
    }
});
bundler.register("tsb_types_15", [], (imports, exports, config) => {
    const { SourceFile } = require("ts-morph");
    {
        let SymbolType;
        (function (SymbolType) {
            SymbolType[SymbolType["FUNCTION"] = 0] = "FUNCTION";
            SymbolType[SymbolType["VARIABLE"] = 1] = "VARIABLE";
            SymbolType[SymbolType["INTERFACE"] = 2] = "INTERFACE";
            SymbolType[SymbolType["TYPE_ALIAS"] = 3] = "TYPE_ALIAS";
            SymbolType[SymbolType["CLASS"] = 4] = "CLASS";
            SymbolType[SymbolType["ENUM"] = 5] = "ENUM";
        })(SymbolType || (SymbolType = {}));
        let ImportKind;
        (function (ImportKind) {
            ImportKind[ImportKind["DEFAULT"] = 0] = "DEFAULT";
            ImportKind[ImportKind["NAMED"] = 1] = "NAMED";
            ImportKind[ImportKind["NAMESPACE"] = 2] = "NAMESPACE";
            ImportKind[ImportKind["INCLUDE"] = 3] = "INCLUDE";
        })(ImportKind || (ImportKind = {}));
        let LibIncludeType;
        (function (LibIncludeType) {
            LibIncludeType[LibIncludeType["SCRIPT"] = 0] = "SCRIPT";
            LibIncludeType[LibIncludeType["ASSET"] = 1] = "ASSET";
        })(LibIncludeType || (LibIncludeType = {}));
        exports["tsb_types_15"].SymbolType = SymbolType;
        exports["tsb_types_15"].ImportKind = ImportKind;
        exports["tsb_types_15"].LibIncludeType = LibIncludeType;
    }
});
bundler.register("tsb_utils_16", [], (imports, exports, config) => {
    const fs = require("fs");
    const path = require("path");
    {
        function list_files(dir) {
            const files = [];
            const loop = (dir) => {
                fs.readdirSync(dir).forEach(value => {
                    if (fs.statSync(path.join(dir, value)).isDirectory()) {
                        loop(path.join(dir, value));
                    }
                    else if (fs.statSync(path.join(dir, value)).isFile()) {
                        files.push(path.join(dir, value));
                    }
                });
            };
            loop(dir);
            return files;
        }
        function list_dirs(dir, growing = true) {
            const dirs = [];
            const loop = (dir) => {
                fs.readdirSync(dir).forEach(value => {
                    if (fs.statSync(path.join(dir, value)).isDirectory()) {
                        if (growing) {
                            dirs.push(path.join(dir, value));
                        }
                        loop(path.join(dir, value));
                        if (!growing) {
                            dirs.push(path.join(dir, value));
                        }
                    }
                });
            };
            loop(dir);
            return dirs;
        }
        let id = 0;
        function shift() {
            if (id >= process.argv.length) {
                return null;
            }
            return process.argv[id++];
        }
        exports["tsb_utils_16"].list_files = list_files;
        exports["tsb_utils_16"].list_dirs = list_dirs;
        exports["tsb_utils_16"].shift = shift;
    }
});
bundler.load("tsb_tsb_0");
