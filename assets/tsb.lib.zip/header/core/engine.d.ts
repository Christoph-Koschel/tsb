import { ClassDeclarationStructure, TypeAliasDeclarationStructure } from "ts-morph";
export declare function build_bundler_types(): TypeAliasDeclarationStructure[];
export declare function build_bundler(): ClassDeclarationStructure;
