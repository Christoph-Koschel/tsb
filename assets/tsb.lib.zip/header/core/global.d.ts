export declare const CWD: string;
export declare const ENGINE_DIR: string;
export declare const CONFIG_FILE: string;
export type BuildOptions = {
    produceTS: boolean;
    option: string | false;
};
export declare const BUILD_OPTIONS: BuildOptions;
