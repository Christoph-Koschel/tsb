export declare function list_files(dir: string): string[];
export declare function list_dirs(dir: string, growing?: boolean): string[];
export declare function shift(): string | null;
