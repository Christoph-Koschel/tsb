import { Node, Project, SourceFile } from "ts-morph";
import { ImportReference, ModuleItem } from "./types";
import { Config } from "./config";
export declare function init_translation(config: Config): void;
export declare function translate_to_id(module: string, path: string, dependencies: string[]): string;
export declare function get_all_translations(module: string): {
    [file: string]: string;
};
export declare function find_by_name(sourceFile: SourceFile, name: string): Node<import("@ts-morph/common/lib/typescript").Node>;
export declare function replace_type_name(module: ModuleItem, name: string, newName: string): void;
export declare function check_diagnostics(project: Project): boolean;
export declare function compare_import(imp1: ImportReference, imp2: ImportReference): boolean;
