export declare function build_output(): void;
