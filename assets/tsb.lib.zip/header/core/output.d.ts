import { Queue, QueueDataGroup } from "./config";
import { Progress } from "clui";
export declare enum Color {
    Black = 0,
    Red = 1,
    Green = 2,
    Yellow = 3,
    Blue = 4,
    Magenta = 5,
    Cyan = 6,
    White = 7,
    Default = 9,
    Reset = -1
}
export type QueueStatusValue = "OK" | "FAIL" | "WARNING" | "WAITING" | "DOING";
export type QueueStatus = {
    queue: Queue<QueueDataGroup>;
    index: number;
    status: QueueStatusValue;
    fullProgressBar: Progress;
    fullProgressValue: number;
    stepProgressBar: Progress;
    stepProgressValue: number;
    title: string;
    statusMessage: string;
    logs: string[];
};
export declare function init_queue_status(queue: Queue<QueueDataGroup>): void;
export declare function colorize(str: string, fore: Color): string;
export declare function set_active(index: number): void;
export declare function set_status(status: QueueStatusValue): void;
export declare function has_status(status: QueueStatusValue): boolean;
export declare function set_step_value(value: number): void;
export declare function set_full_value(value: number): void;
export declare function write_status_message(message: string): void;
export declare function write_title(title: string): void;
export declare function write_error(error: string): void;
export declare function write_warning(warning: string): void;
export declare function write_log(text: string): void;
