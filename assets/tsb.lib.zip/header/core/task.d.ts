import { CompileModuleData, Config, CopyData, PackData, RemoveData } from "./config";
export declare function compile_module_task(config: Config, information: CompileModuleData): void;
export declare function pack_module_task(config: Config, information: PackData): void;
export declare function copy_task(information: CopyData): void;
export declare function remove_task(information: RemoveData): void;
