export default function pack(): void;
