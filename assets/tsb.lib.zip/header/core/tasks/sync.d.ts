export default function sync(): void;
