export default function init(): void;
