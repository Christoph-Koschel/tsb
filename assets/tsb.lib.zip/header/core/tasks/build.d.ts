export default function build(): void;
