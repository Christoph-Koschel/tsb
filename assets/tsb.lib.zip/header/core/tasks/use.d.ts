import * as AdmZip from "adm-zip";
export default function use(): void;
export declare function extract_file(zip: AdmZip): void;
