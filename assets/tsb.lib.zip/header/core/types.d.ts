import { SourceFile } from "ts-morph";
export type ModuleItem = {
    rawFilename: string;
    filename: string;
    module: SourceFile;
};
export type CompilerResult = {
    name: string;
    sourceFile: SourceFile;
    file_map: {
        [file: string]: string;
    };
};
export declare enum SymbolType {
    FUNCTION = 0,
    VARIABLE = 1,
    INTERFACE = 2,
    TYPE_ALIAS = 3,
    CLASS = 4,
    ENUM = 5
}
export declare enum ImportKind {
    DEFAULT = 0,
    NAMED = 1,
    NAMESPACE = 2,
    INCLUDE = 3
}
export type ImportReferenceItem = {
    name: string;
    alias: string;
    type: SymbolType;
};
export type ImportReference = {
    path: string;
    items: ImportReferenceItem[];
    kind: ImportKind;
    from: "MODULE" | "FILE";
};
export type ExportReference = {
    from: string;
    local: string;
    global: string;
    type: SymbolType;
};
export type LibConfig = {
    name: string;
    scripts: string[];
    assets: {
        src: string;
        dest: string;
    }[];
};
export declare enum LibIncludeType {
    SCRIPT = 0,
    ASSET = 1
}
export type LibScriptIncludeItem = {
    type: LibIncludeType.SCRIPT;
    src: string;
    vdest: string;
};
export type LibAssetIncludeItem = {
    type: LibIncludeType.ASSET;
    src: string;
    vdest: string;
    dest: string;
};
export type LibIncludeItem = LibScriptIncludeItem | LibAssetIncludeItem;
