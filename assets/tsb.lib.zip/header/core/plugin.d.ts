import { Serializable } from "./config";
import { LibIncludeItem, ModuleItem } from "./types";
import { ClassDeclarationStructure, CodeBlockWriter } from "ts-morph";
export type PluginResultInformation = {
    outDir: string;
    outName: string;
    outPath: string;
    engineDir: string;
    module: string;
};
export declare abstract class Plugin {
    abstract get name(): string;
    abstract init(args: Serializable[]): void;
    modify(module: ModuleItem): void;
    generate(): ClassDeclarationStructure[];
    beforeLoad(writer: CodeBlockWriter, information: PluginResultInformation): void;
    result(fileContent: string, information: PluginResultInformation): string | null;
    sync(information: PluginResultInformation): void;
    pack(information: PluginResultInformation): LibIncludeItem[] | false;
}
export declare class PluginHandler {
    private static plugins;
    static register(plugin: Plugin): void;
    static instantiate(name: string, parameters: Serializable[]): Plugin | null;
    static names(): string;
}
